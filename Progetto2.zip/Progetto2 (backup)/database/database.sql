-- Creazione della tabella 'utenti' (senza distinzione tra organizzatori e partecipanti)
CREATE TABLE IF NOT EXISTS utenti (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    cognome TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    telefono TEXT NOT NULL,
    data_nascita TEXT NOT NULL,
    password TEXT NOT NULL
);

-- Creazione della tabella 'eventi'
CREATE TABLE IF NOT EXISTS eventi (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    data_inizio TEXT NOT NULL,
    data_fine TEXT NOT NULL,
    posti INTEGER NOT NULL,
    descrizione TEXT,
    organizzatore_id INTEGER,
    FOREIGN KEY (organizzatore_id) REFERENCES utenti(id)
);

-- Creazione della tabella 'partecipazioni'
CREATE TABLE IF NOT EXISTS partecipazioni (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    utente_id INTEGER NOT NULL,
    evento_id INTEGER NOT NULL,
    FOREIGN KEY (utente_id) REFERENCES utenti(id),
    FOREIGN KEY (evento_id) REFERENCES eventi(id),
    UNIQUE(utente_id, evento_id)  -- Garantisce che un utente non possa partecipare allo stesso evento più di una volta
);
