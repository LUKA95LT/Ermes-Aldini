function dati() {
    let nome = document.getElementById("nome").value.trim();
    let cognome = document.getElementById("cognome").value.trim();
    let nascita = document.getElementById("nascita").value;
    let email = document.getElementById("email").value.trim();
    let numero = document.getElementById("numero").value.trim();
    let ricercaEvento = document.getElementById("ricerca_evento").value.trim();

    if (!nome || !cognome || !nascita || !email || !numero || !ricercaEvento) {
        showModal("Errore", "Tutti i campi devono essere compilati.");
        return;
    }

    let dataCorrente = new Date();
    let dataNascita = new Date(nascita);
    let eta = dataCorrente.getFullYear() - dataNascita.getFullYear();
    let mesi = dataCorrente.getMonth() - dataNascita.getMonth();
    let giorni = dataCorrente.getDate() - dataNascita.getDate();

    if (mesi < 0 || (mesi === 0 && giorni < 0)) {
        eta--;
    }

    if (eta < 18) {
        showModal("Errore", "Non hai ancora raggiunto la maggiore età, non puoi partecipare!");
        return;
    }

    let eventi = JSON.parse(localStorage.getItem('eventi')) || [];

    let eventiTrovati = eventi.filter(function (evento) {
        return evento.nomeEvento.toLowerCase().includes(ricercaEvento.toLowerCase()) ||
            (evento.nome + ' ' + evento.cognome).toLowerCase().includes(ricercaEvento.toLowerCase()) ||
            evento.descrizione.toLowerCase().includes(ricercaEvento.toLowerCase());
    });

    if (eventiTrovati.length > 0) {
        let eventiValidi = eventiTrovati.filter(evento => {
            let dataFineEvento = new Date(evento.dataFine);
            return dataFineEvento > dataCorrente;
        });

        if (eventiValidi.length > 0) {
            displayEventSelectionModal(eventiValidi, nome, cognome, nascita, email, numero);
        } else {
            showModal("Errore", "Tutti gli eventi trovati sono già scaduti.");
        }
    } else {
        showModal("Ricerca", "Nessun evento trovato corrispondente alla ricerca.");
    }
}

function displayEventSelectionModal(eventiTrovati, nome, cognome, nascita, email, numero) {
    const selezionaElemento = document.getElementById('seleziona');

    let eventiDropdown = eventiTrovati.map((evento, index) => `
        <option value="${index}">
            ${evento.nomeEvento} - ${evento.nome} ${evento.cognome} (Posti: ${evento.posti})
        </option>
    `).join('');

    const modalHtml = `
        <div id="event-selection-modal">
            <h2 class="text-2xl font-bold mb-4">Seleziona un Evento</h2>
            <select id="evento-selezionato" class="w-full p-2 mb-4 border rounded">
                <option value="">Scegli un evento</option>
                ${eventiDropdown}
            </select>
            <div id="evento-dettagli" class="mb-4"></div>
        </div>
    `;

    selezionaElemento.innerHTML = modalHtml;

    document.getElementById('evento-selezionato').addEventListener('change', function () {
        const indiceEvento = this.value;
        const dettagliDiv = document.getElementById('evento-dettagli');

        if (indiceEvento) {
            const evento = eventiTrovati[indiceEvento];
            dettagliDiv.innerHTML = `
                <p><strong>Nome Evento:</strong> ${evento.nomeEvento}</p>
                <p><strong>Organizzatore:</strong> ${evento.nome} ${evento.cognome}</p>
                <p><strong>Date:</strong> ${evento.dataInizio} - ${evento.dataFine}</p>
                <p><strong>Posti Disponibili:</strong> ${evento.posti}</p>
                <p><strong>Descrizione:</strong> ${evento.descrizione}</p>
                <button style="color: black;" onclick="selectEventFromDropdown()">Conferma</button>
            `;
        } else {
            dettagliDiv.innerHTML = '';
        }
    });

    window.currentUser = { nome, cognome, nascita, email, numero };
    window.currentEvents = eventiTrovati;
}

function selectEventFromDropdown() {
    const indiceEvento = document.getElementById('evento-selezionato').value;
    if (!indiceEvento) {
        showModal("Errore", "Devi selezionare un evento.");
        return;
    }

    const eventoSelezionato = window.currentEvents[indiceEvento];
    showModal("Evento Selezionato", `Hai selezionato: ${eventoSelezionato.nomeEvento}`);
    closeModalAndReset();
}

function closeModalAndReset() {
    document.getElementById('seleziona').innerHTML = '';
}

function showModal(titolo, messaggio) {
    alert(`${titolo}: ${messaggio}`);
}
