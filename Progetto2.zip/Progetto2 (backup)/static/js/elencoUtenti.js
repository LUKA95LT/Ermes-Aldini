document.addEventListener('DOMContentLoaded', function() {
    let container = document.getElementById('utenti-container');

    function aggiornaCard() {
        container.innerHTML = '';
        if (partecipanti.length === 0) {
            container.innerHTML = `<p>Nessun partecipante registrato per questo evento.</p>`;
            return;
        }

        partecipanti.forEach(function(partecipante) {
            let card = document.createElement('div');
            card.className = 'card mb-3';
            card.style.width = '400px';

            let cardBody = document.createElement('div');
            cardBody.className = 'card-body';

            let cardTitle = document.createElement('h4');
            cardTitle.className = 'card-title';
            cardTitle.textContent = partecipante.nome + ' ' + partecipante.cognome;

            let cardText = document.createElement('p');
            cardText.className = 'card-text';
            cardText.innerHTML = `Email: ${partecipante.email}`;

            cardBody.appendChild(cardTitle);
            cardBody.appendChild(cardText);
            card.appendChild(cardBody);
            container.appendChild(card);
        });
    }

    aggiornaCard();
});
