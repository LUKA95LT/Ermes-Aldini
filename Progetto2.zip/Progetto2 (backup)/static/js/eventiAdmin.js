document.addEventListener('DOMContentLoaded', function() {
    let eventi = JSON.parse(localStorage.getItem('eventi')) || [];
    let container = document.getElementById('eventi-container');

    function aggiornaCard() {
        container.innerHTML = '';
        eventi.forEach(function(evento, index) {
            let card = document.createElement('div');
            card.className = 'card mb-3 evento-card';
            card.style.width = '400px';
    
            let cardBody = document.createElement('div');
            cardBody.className = 'card-body';

            let checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.className = 'evento-checkbox';
            checkbox.dataset.index = index;

            cardBody.appendChild(checkbox);
    
            let cardTitle = document.createElement('h4');
            cardTitle.className = 'card-title';
            cardTitle.textContent = evento.nome + ' ' + evento.cognome;
    
            let cardText = document.createElement('p');
            cardText.className = 'card-text';
            cardText.innerHTML = 'Email: ' + evento.email + '<br>' + 
                                    'Cellulare: ' + evento.numero + '<br>' + 
                                    'Nome Evento: ' + evento.nomeEvento + '<br>' + 
                                    'Data Inizio: ' + evento.dataInizio + '<br>' + 
                                    'Data Fine: ' + evento.dataFine + '<br>' + 
                                    'Posti disponibili: ' + evento.posti + '<br>' + 
                                    'Descrizione: ' + evento.descrizione;
    
            let visualizzaUtentiBtn = document.createElement('button');
            visualizzaUtentiBtn.className = 'btn btn-primary mt-2';
            visualizzaUtentiBtn.textContent = 'Visualizza utenti';
            visualizzaUtentiBtn.dataset.evento = evento.nomeEvento;
            visualizzaUtentiBtn.addEventListener('click', function() {
                window.location.href = `elencoUtenti.html?evento=${encodeURIComponent(evento.nomeEvento)}`;
            });
            
    
            cardBody.appendChild(cardTitle);
            cardBody.appendChild(cardText);
            cardBody.appendChild(visualizzaUtentiBtn);
            card.appendChild(cardBody);
            container.appendChild(card);
        });
    }
        

    aggiornaCard();

    document.getElementById('ripristina').addEventListener('click', function() {
        localStorage.removeItem('eventi');
        eventi = [];
        aggiornaCard();
    });

    document.getElementById('eliminaSelezionati').addEventListener('click', function() {
        let checkboxes = document.querySelectorAll('.evento-checkbox:checked');
        let indiciDaEliminare = Array.from(checkboxes).map(cb => parseInt(cb.dataset.index));
        
        eventi = eventi.filter((_, index) => !indiciDaEliminare.includes(index));
        
        localStorage.setItem('eventi', JSON.stringify(eventi));
        aggiornaCard();
    });

    document.getElementById('stampa').addEventListener('click', function() {
        let checkboxes = document.querySelectorAll('.evento-checkbox:checked');
        let selectedCards = Array.from(checkboxes).map(cb => cb.closest('.evento-card'));
        if (selectedCards.length > 0) {
            let printWindow = window.open('', '', 'width=800,height=600');
            printWindow.document.write('<html><head><title>Stampa Eventi Selezionati</title></head><body>');
            selectedCards.forEach(card => {
                printWindow.document.write(card.outerHTML);
            });
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        }
    });

    document.getElementById('stampaTutti').addEventListener('click', function() {
        let printWindow = window.open('', '', 'width=800,height=600');
        printWindow.document.write('<html><head><title>Stampa Tutti gli Eventi</title><style>@page { size: A4; margin: 20mm; } .evento-card { page-break-after: always; }</style></head><body>');
        eventi.forEach(evento => {
            printWindow.document.write('<div class="evento-card" style="width: 100%; padding: 20px; border: 1px solid #000; margin-bottom: 20px;">');
            printWindow.document.write('<h4>' + evento.nome + ' ' + evento.cognome + '</h4>');
            printWindow.document.write('<p>Email: ' + evento.email + '<br>');
            printWindow.document.write('Cellulare: ' + evento.numero + '<br>');
            printWindow.document.write('Nome Evento: ' + evento.nomeEvento + '<br>');
            printWindow.document.write('Data Inizio: ' + evento.dataInizio + '<br>');
            printWindow.document.write('Data Fine: ' + evento.dataFine + '<br>');
            printWindow.document.write('Posti disponibili: ' + evento.posti + '<br>');
            printWindow.document.write('Descrizione: ' + evento.descrizione + '<br>');
            printWindow.document.write('Organizzatore ID: ' + evento.organizzatoreId + '</p>');
            printWindow.document.write('</div>');
        });
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.print();
    });

    function visualizzaElencoUtenti(nomeEvento) {
        let utenti = JSON.parse(localStorage.getItem('utenti')) || [];
        let utentiEvento = utenti.filter(u => u.nomeEvento === nomeEvento);
    
        let elencoHtml = '<h3>Partecipanti a ' + nomeEvento + '</h3>';
        if (utentiEvento.length > 0) {
            elencoHtml += '<ul>';
            utentiEvento.forEach(utente => {
                elencoHtml += `<li>${utente.nome} ${utente.cognome} - Email: ${utente.email} - Cellulare: ${utente.numero}</li>`;
            });
            elencoHtml += '</ul>';
        } else {
            elencoHtml += '<p>Nessun utente iscritto a questo evento.</p>';
        }
    
        let modalHtml = `
            <div id="modal-utenti" class="modal-style">
                ${elencoHtml}
                <button onclick="chiudiModal()" class="btn btn-secondary mt-2">Chiudi</button>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', modalHtml);
    }
    
    function chiudiModal() {
        document.getElementById('modal-utenti').remove();
    }
    
});

