document.addEventListener('DOMContentLoaded', function () {
  let eventi;

  fetch('https://192.168.8.239:8000/eventi')
    .then(response => {
      if (!response.ok) {
        throw new Error('Errore nella risposta del server');
      }
      return response.json();
    })
    .then(data => {
      eventi = data;
      aggiornaCard();
    })
    .catch(error => {
      console.error('Errore nel recupero degli eventi:', error);
    });

  let container = document.getElementById('eventi-container');
  const nessunRisultato = document.getElementById("nessun-risultato");

  if (nessunRisultato && nessunRisultato.value === "true") {
    alert("Nessun evento trovato! Riprova con un altro nome.");
  }

  function aggiornaCard() {
    container.innerHTML = '';

    if (eventi.length === 0) {
      container.innerHTML = '<p>Nessun evento trovato.</p>';
    } else {
      eventi.forEach(function (evento) {
        let card = document.createElement('div');
        card.className = 'card mb-3';
        card.style.width = '400px';

        let cardBody = document.createElement('div');
        cardBody.className = 'card-body';

        let cardTitle = document.createElement('h4');
        cardTitle.className = 'card-title';
        cardTitle.textContent = evento.nome;

        let cardText = document.createElement('p');
        cardText.className = 'card-text';
        cardText.innerHTML =
          `Email: ${evento.email} <br>
          Cellulare: ${evento.numero} <br>
          Nome Evento: ${evento.nomeEvento} <br>
          Data Inizio: ${evento.dataInizio} <br>
          Data Fine: ${evento.dataFine} <br>
          Posti disponibili: <span id="posti-${evento.id}">${evento.posti}</span> <br>
          Descrizione: ${evento.descrizione} <br>
          Organizzatore ID: ${evento.organizzatoreId}`;

        let participateButton = document.createElement('button');
        participateButton.className = 'btn btn-success';
        participateButton.id = `partecipareButton-${evento.id}`;
        participateButton.textContent = 'Partecipa';
        participateButton.onclick = function () {
          partecipaEvento(evento.id);
        };

        cardBody.appendChild(cardTitle);
        cardBody.appendChild(cardText);
        cardBody.appendChild(participateButton);
        card.appendChild(cardBody);
        container.appendChild(card);
      });
    }
  }

  function partecipaEvento(eventoId) {
    // Implement the function to handle event participation
    console.log(`Partecipazione all'evento con ID: ${eventoId}`);
  }
});