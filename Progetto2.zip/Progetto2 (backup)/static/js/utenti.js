document.addEventListener('DOMContentLoaded', async function () {
    try {
        const response = await fetch('/utenti_lista');
        if (!response.ok) {
            throw new Error('Errore nel recupero degli utenti');
        }

        const utenti = await response.json();
        const utentiContainer = document.getElementById('utenti-container');

        if (utenti && utenti.length > 0) {
            utentiContainer.innerHTML = '';  

            utenti.forEach(utente => {
                let card = document.createElement('div');
                card.className = 'card mb-3';
                card.style.width = '400px';

                let cardBody = document.createElement('div');
                cardBody.className = 'card-body';

                let cardTitle = document.createElement('h4');
                cardTitle.className = 'card-title';
                cardTitle.textContent = `${utente.nome} ${utente.cognome}`;

                let cardText = document.createElement('p');
                cardText.className = 'card-text';
                cardText.innerHTML = `
                    <strong>Data di Nascita:</strong> ${utente.data_nascita} <br>
                    <strong>Email:</strong> ${utente.email} <br>
                    <strong>Telefono:</strong> ${utente.telefono} <br>
                    <strong>ID Partecipante:</strong> ${utente.partecipanteId}
                `;

                cardBody.appendChild(cardTitle);
                cardBody.appendChild(cardText);
                card.appendChild(cardBody);
                utentiContainer.appendChild(card);
            });

        } else {
            utentiContainer.innerHTML = '<p style="text-align: center;">Nessun utente registrato.</p>';
        }

    } catch (error) {
        console.error('Errore:', error);
        document.getElementById('utenti-container').innerHTML = 
            '<p style="text-align: center;">Errore nel caricamento degli utenti.</p>';
    }
});
