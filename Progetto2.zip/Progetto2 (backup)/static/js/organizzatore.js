document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("registrazione-form");

  form.addEventListener("submit", async function (event) {
    event.preventDefault();

    const organizzatore = new FormData();
    organizzatore.append("nome", document.getElementById("nome").value.trim());
    organizzatore.append("cognome", document.getElementById("cognome").value.trim());
    organizzatore.append("email", document.getElementById("email").value.trim());
    organizzatore.append("telefono", document.getElementById("numero").value.trim());
    organizzatore.append("data_nascita", document.getElementById("nascita").value);

    const dataCorrente = new Date();
    const dataNascita = new Date(document.getElementById("nascita").value);
    let eta = dataCorrente.getFullYear() - dataNascita.getFullYear();
    const mesi = dataCorrente.getMonth() - dataNascita.getMonth();
    const giorni = dataCorrente.getDate() - dataNascita.getDate();
    if (mesi < 0 || (mesi === 0 && giorni < 0)) {
      eta--;
    }
    if (eta < 18) {
      alert("Errore: Devi essere maggiorenne per registrarti come organizzatore!");
      return;
    }

    try {
      const response = await fetch("http://192.168.8.239:8000/crea_organizzatore", {
        method: "POST",
        body: organizzatore
      });

      if (response.status === 409) {
        const errorData = await response.json();
        alert(errorData.detail || "Sei già registrato");
        return;
      }

      if (!response.ok) {
        alert("Errore durante la registrazione!");
        throw new Error("Errore nella registrazione");
      }

      const data = await response.json();

      if (
        !data.nome ||
        !data.cognome ||
        !data.email ||
        !data.telefono ||
        !data.organizzatoreId
      ) {
        console.error("Dati incompleti ricevuti dal server.");
        return;
      }

      const card = document.getElementById("organizzatore-card");
      card.style.display = "block";

      document.getElementById("card-nome").innerText = `${data.nome} ${data.cognome}`;
      document.getElementById("card-info").innerHTML = `
            <strong>Email:</strong> ${data.email} <br>
            <strong>Cellulare:</strong> ${data.telefono} <br>
            <strong>Organizzatore ID:</strong> ${data.organizzatoreId}
        `;
      const creaEventoBtn = document.getElementById("crea-evento-btn");
      if (creaEventoBtn) {
        creaEventoBtn.style.display = "block";
      }
    } catch (error) {
      console.error("Errore nella richiesta:", error);
    }
  });
});
