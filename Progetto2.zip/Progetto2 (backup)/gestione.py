import sqlite3

def get_db_connection():
    conn = sqlite3.connect('eventi.db')
    conn.row_factory = sqlite3.Row 
    return conn

def create_tables():
    try:
        with get_db_connection() as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS utenti (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome TEXT NOT NULL,
                    cognome TEXT NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    telefono TEXT NOT NULL,
                    data_nascita TEXT NOT NULL
                )
            ''')
            conn.execute('''
                CREATE TABLE IF NOT EXISTS eventi (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nome TEXT NOT NULL,
                    data_inizio TEXT NOT NULL,
                    data_fine TEXT NOT NULL,
                    posti INTEGER NOT NULL,
                    descrizione TEXT,
                    organizzatore_id INTEGER,
                    FOREIGN KEY(organizzatore_id) REFERENCES utenti(id)
                )
            ''')
            conn.execute('''
                CREATE TABLE IF NOT EXISTS partecipazioni (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    utente_id INTEGER NOT NULL,
                    evento_id INTEGER NOT NULL,
                    FOREIGN KEY(utente_id) REFERENCES utenti(id),
                    FOREIGN KEY(evento_id) REFERENCES eventi(id),
                    UNIQUE(utente_id, evento_id)
                )
            ''')
            conn.commit()
        print("Tabelle create con successo.")
    except sqlite3.Error as e:
        print(f"Errore durante la creazione delle tabelle: {e}")

def crea_utente():
    nome = input("Inserisci nome: ").strip()
    cognome = input("Inserisci cognome: ").strip()
    email = input("Inserisci email: ").strip()
    telefono = input("Inserisci numero di telefono: ").strip()
    data_nascita = input("Inserisci data di nascita (YYYY-MM-DD): ").strip()

    try:
        with get_db_connection() as conn:
            cursor = conn.execute("SELECT * FROM utenti WHERE email = ?", (email,))
            if cursor.fetchone() is not None:
                print("Alert: Email già in uso!")
                return

            conn.execute('''
            INSERT INTO utenti (nome, cognome, email, telefono, data_nascita)
            VALUES (?, ?, ?, ?, ?)
            ''', (nome, cognome, email, telefono, data_nascita))
            conn.commit()

            cursor = conn.cursor()
            cursor.execute('SELECT last_insert_rowid()')
            utente_id = cursor.fetchone()[0]
        
        print(f"Utente creato con successo! Il tuo ID è: {utente_id}")
    except sqlite3.Error as e:
        print(f"Errore durante la creazione dell'utente: {e}")

def crea_evento():
    try:
        organizzatore_id = int(input("Inserisci ID organizzatore: "))
        nome = input("Inserisci nome evento: ").strip()
        data_inizio = input("Inserisci data inizio (YYYY-MM-DD): ").strip()
        data_fine = input("Inserisci data fine (YYYY-MM-DD): ").strip()
        posti = int(input("Inserisci posti disponibili: "))
        descrizione = input("Inserisci descrizione evento: ").strip()

        with get_db_connection() as conn:
            conn.execute('''
            INSERT INTO eventi (nome, data_inizio, data_fine, posti, descrizione, organizzatore_id)
            VALUES (?, ?, ?, ?, ?, ?)
            ''', (nome, data_inizio, data_fine, posti, descrizione, organizzatore_id))
            conn.commit()

            cursor = conn.cursor()
            cursor.execute('SELECT last_insert_rowid()')
            evento_id = cursor.fetchone()[0]
        
        print(f"Evento creato con successo! L'ID dell'evento è: {evento_id}")
    except ValueError:
        print("Errore: ID organizzatore e posti devono essere numeri interi.")
    except sqlite3.Error as e:
        print(f"Errore durante la creazione dell'evento: {e}")

def mostra_eventi():
    try:
        with get_db_connection() as conn:
            eventi = conn.execute('SELECT * FROM eventi').fetchall()

        if eventi:
            for evento in eventi:
                print(f"ID: {evento['id']} - Nome: {evento['nome']} - Inizio: {evento['data_inizio']} - Fine: {evento['data_fine']} - Posti: {evento['posti']}")
        else:
            print("Non ci sono eventi disponibili.")
    except sqlite3.Error as e:
        print(f"Errore durante la visualizzazione degli eventi: {e}")

def partecipa_evento():
    try:
        utente_id = int(input("Inserisci il tuo ID utente: "))
        evento_id = int(input("Inserisci l'ID dell'evento a cui vuoi partecipare: "))

        with get_db_connection() as conn:
            conn.execute('''
            INSERT INTO partecipazioni (utente_id, evento_id)
            VALUES (?, ?)
            ''', (utente_id, evento_id))
            conn.commit()
        
        print("Partecipazione registrata!")
    except ValueError:
        print("Errore: ID utente e ID evento devono essere numeri interi.")
    except sqlite3.Error as e:
        print(f"Errore durante la registrazione della partecipazione: {e}")

def main():
    while True:
        print("1. Crea utente")
        print("2. Crea evento")
        print("3. Mostra eventi")
        print("4. Partecipa evento")
        print("5. Esci")
        scelta = input("Scegli un'opzione: ").strip()
        
        if scelta == '1':
            crea_utente()
        elif scelta == '2':
            crea_evento()
        elif scelta == '3':
            mostra_eventi()
        elif scelta == '4':
            partecipa_evento()
        elif scelta == '5':
            break
        else:
            print("Opzione non valida.")

if __name__ == '__main__':
    create_tables()
    main()
