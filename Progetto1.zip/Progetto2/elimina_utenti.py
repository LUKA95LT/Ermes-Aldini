import sqlite3

def elimina_utenti(solo_id=None):
    conn = sqlite3.connect('eventi.db')
    cursor = conn.cursor()
    
    if solo_id is None:
        # Elimina tutti gli eventi
        query = "DELETE FROM utenti;"
        cursor.execute(query)
    else:
        # Elimina l'evento con un id specifico
        query = "DELETE FROM eventi WHERE id = ?;"
        cursor.execute(query, (solo_id,))
    
    conn.commit()
    conn.close()
    print("Eliminazione completata.")

# Per eliminare tutti gli utenti:
elimina_utenti()

# Per eliminare l'utente con id = 3:
# elimina_utenti(solo_id=3)