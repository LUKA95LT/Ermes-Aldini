from fastapi import FastAPI, Form, HTTPException, Request, Depends
from fastapi import Query
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
from jose import JWTError, jwt
from datetime import datetime, timedelta
from pathlib import Path
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import RedirectResponse
import sqlite3
import bcrypt
from typing import Optional


SECRET_KEY = "IAV2017!!"  # Cambia con la tua chiave segreta
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

app = FastAPI()

class Partecipazione(BaseModel):
    userId: int

class LoginData(BaseModel):
    email: str
    password: str

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

class PartecipaRequest(BaseModel):
   utente_id: int

templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")

def verifica_utente(email: str, password: str):
    conn = sqlite3.connect("eventi.db")  # Assicurati di usare il database corretto
    cursor = conn.cursor()

    # Recupera l'utente in base all'email
    query = "SELECT id, password FROM utenti WHERE email = ?"
    cursor.execute(query, (email,))
    user = cursor.fetchone()
    conn.close()

    if user:
        user_id, hashed_password = user
        # Confronta la password in chiaro con l'hash salvato nel database
        if bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8')):
            return {"id": user_id}  # Restituisce l'ID utente se la password è corretta
    return None  # Restituisce None se l'utente non esiste o la password è errata

def get_db_connection():
   conn = sqlite3.connect('eventi.db')
   conn.row_factory = sqlite3.Row
   return conn

def create_access_token(data: dict, expires_delta: timedelta = None):
   to_encode = data.copy()
   if expires_delta:
       expire = datetime.utcnow() + expires_delta
   else:
       expire = datetime.utcnow() + timedelta(minutes=15)
   to_encode.update({"exp": expire})
   encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
   return encoded_jwt

def get_current_user(token: str = Depends(oauth2_scheme)):
   credentials_exception = HTTPException(
       status_code=401,
       detail="Could not validate credentials",
       headers={"WWW-Authenticate": "Bearer"},
   )
   try:
       payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
       user_id: str = payload.get("sub")
       if user_id is None:
           raise credentials_exception
   except JWTError as e:
       print(f"Errore JWT: {e}")
       raise credentials_exception
   return user_id

@app.post("/token", response_model=dict)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
   username = form_data.username
   password = form_data.password
  
   if username != "testuser" or password != "testpassword":
       raise HTTPException(status_code=400, detail="Credenziali non valide")

   access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
   access_token = create_access_token(data={"sub": username}, expires_delta=access_token_expires)
   return {"access_token": access_token, "token_type": "bearer"}

@app.post("/api/partecipa/{event_id}", response_class=JSONResponse)
async def partecipa(event_id: int, partecipazione: Partecipazione):
    try:
        # Debug: stampa i valori ricevuti
        print(f"Richiesta di partecipazione: event_id={event_id}, userId={partecipazione.userId}")
        conn = sqlite3.connect("eventi.db")
        cursor = conn.cursor()

        # Controlla se l'utente è già registrato all'evento
        query_check = "SELECT COUNT(*) FROM partecipazioni WHERE utente_id = ? AND evento_id = ?"
        cursor.execute(query_check, (partecipazione.userId, event_id))
        if cursor.fetchone()[0] > 0:
            print("L'utente è già registrato")
            return JSONResponse(status_code=400, content={"message": "Hai già partecipato a questo evento"})

        # Controlla il numero di posti disponibili
        query_posti = "SELECT posti FROM eventi WHERE id = ?"
        cursor.execute(query_posti, (event_id,))
        result = cursor.fetchone()
        if not result or result[0] <= 0:
            print("Posti non disponibili")
            raise HTTPException(status_code=400, detail="Non ci sono più posti disponibili per questo evento")
        current_posti = result[0]
        print(f"Posti disponibili prima dell'iscrizione: {current_posti}")

        # Aggiorna i posti disponibili
        query_update_posti = "UPDATE eventi SET posti = posti - 1 WHERE id = ?"
        cursor.execute(query_update_posti, (event_id,))

        # Inserisci la partecipazione
        query_insert = "INSERT INTO partecipazioni (utente_id, evento_id) VALUES (?, ?)"
        cursor.execute(query_insert, (partecipazione.userId, event_id))
        conn.commit()
        conn.close()
        print("Partecipazione registrata")
        return JSONResponse(content={"message": f"Partecipazione registrata con successo. Posti rimanenti: {current_posti - 1}"})
    except sqlite3.IntegrityError as e:
        print("Errore di integrità:", e)
        raise HTTPException(status_code=400, detail="Utente già registrato a questo evento")
    except Exception as e:
        print("Errore generico:", e)
        raise HTTPException(status_code=500, detail=str(e))
    
@app.get("/users/me", response_model=dict)
async def read_users_me(token: str = Depends(oauth2_scheme)):
   credentials_exception = HTTPException(
       status_code=401,
       detail="Could not validate credentials",
       headers={"WWW-Authenticate": "Bearer"},
   )
   try:
       payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
       username: str = payload.get("sub")
       if username is None:
           credentials_exception
   except JWTError:
       raise credentials_exception
   return {"username": username}

@app.get("/", response_class=HTMLResponse)
async def read_index(request: Request):
   return templates.TemplateResponse("index.html", {"request": request})

@app.get("/utenti", response_class=HTMLResponse)
async def read_utenti(request: Request):
   try:
       with get_db_connection() as conn:
           utenti = conn.execute('SELECT * FROM utenti').fetchall()
       return templates.TemplateResponse("utenti.html", {"request": request, "utenti": utenti})
   except sqlite3.Error as e:
       return {"error": f"Errore nel recupero degli utenti: {e}"}

class User(BaseModel):
   nome: str
   cognome: str
   email: str
   telefono: str
   data_nascita: str

@app.post("/crea_utente")
async def crea_utente(
   nome: str = Form(...),
   cognome: str = Form(...),
   email: str = Form(...),
   telefono: str = Form(...),
   data_nascita: str = Form(...)
):
   try:
       with get_db_connection() as conn:
           cursor = conn.execute('SELECT * FROM utenti WHERE email = ?', (email,))
           existing_email = cursor.fetchone()
           if existing_email:
               raise HTTPException(status_code=409, detail="Email già in uso")
           conn.execute('''
               INSERT INTO utenti (nome, cognome, email, telefono, data_nascita)
               VALUES (?, ?, ?, ?, ?)
           ''', (nome, cognome, email, telefono, data_nascita))
           conn.commit()
       return {"message": "Utente creato con successo!"}
   except HTTPException as e:
       raise e
   except sqlite3.Error as e:
       return {"error": f"Errore durante la creazione dell'utente: {e}"}

@app.post("/crea_partecipante")
async def crea_partecipante(
   nome: str = Form(...),
   cognome: str = Form(...),
   email: str = Form(...),
   telefono: str = Form(...),
   data_nascita: str = Form(...)
):
   try:
       with get_db_connection() as conn:
           cursor = conn.execute('SELECT * FROM utenti WHERE email = ?', (email,))
           existing_email = cursor.fetchone()
           if existing_email:
               raise HTTPException(status_code=409, detail="Email già in uso")
           conn.execute('''
               INSERT INTO utenti (nome, cognome, email, telefono, data_nascita)
               VALUES (?, ?, ?, ?, ?)
           ''', (nome, cognome, email, telefono, data_nascita))
           conn.commit()
           cursor = conn.execute("SELECT last_insert_rowid()")
           id_partecipante = cursor.fetchone()[0]
       return {
           "message": "Partecipante creato con successo!",
           "nome": nome,
           "cognome": cognome,
           "email": email,
           "telefono": telefono,
           "data_nascita": data_nascita,
           "partecipanteId": id_partecipante
       }
   except HTTPException as e:
       raise e
   except sqlite3.Error as e:
       return {"error": f"Errore durante la creazione del partecipante: {e}"}

@app.get("/partecipante", response_class=HTMLResponse)
async def read_partecipante(request: Request):
   return templates.TemplateResponse("partecipante.html", {"request": request})

@app.get("/utenti_lista")
async def get_utenti():
   try:
       with get_db_connection() as conn:
           utenti = conn.execute('SELECT * FROM utenti').fetchall()
       utenti_lista = [
           {
               "nome": utente["nome"],
               "cognome": utente["cognome"],
               "data_nascita": utente["data_nascita"],
               "email": utente["email"],
               "telefono": utente["telefono"],
               "partecipanteId": utente["id"] 
           }
           for utente in utenti
       ]
       return utenti_lista
   except sqlite3.Error as e:
       return {"error": f"Errore nel recupero degli utenti: {e}"}

@app.get("/organizzatore", response_class=HTMLResponse)
async def read_organizzatore(request: Request):
   return templates.TemplateResponse("organizzatore.html", {"request": request})

@app.get("/crea_evento", response_class=HTMLResponse)
async def get_crea_evento(request: Request):
   msg = request.query_params.get("message")
   error = request.query_params.get("error")
   return templates.TemplateResponse("crea_evento.html", {"request": request, "message": msg, "error": error})

@app.post("/crea_evento")
async def crea_evento(
    nome_evento: str = Form(...),
    data_inizio: str = Form(...),
    data_fine: str = Form(...),
    posti: int = Form(...),
    descrizione: str = Form(...)
):
    try:
         with get_db_connection() as conn:
              conn.execute('''
                    INSERT INTO eventi (nome, data_inizio, data_fine, posti, descrizione)
                    VALUES (?, ?, ?, ?, ?)
              ''', (nome_evento, data_inizio, data_fine, posti, descrizione))
              conn.commit()
         return {"message": "Evento creato con successo!"}
    except sqlite3.Error as e:
         return {"error": f"Errore durante la creazione dell'evento: {e}"}

@app.get("/ricerca_eventi")
async def ricerca_eventi(query: str):
   try:
       with get_db_connection() as conn:
           eventi = conn.execute('SELECT * FROM eventi WHERE nome LIKE ?', ('%' + query + '%',)).fetchall()
           if eventi:
               return {"evento_trovato": True}
           else:
               return {"evento_trovato": False}
   except sqlite3.Error as e:
       return {"error": f"Errore durante la ricerca degli eventi: {e}"}

@app.get("/eventiP", response_class=HTMLResponse)
async def get_eventiP(request: Request):
   try:
       with get_db_connection() as conn:
           events = conn.execute("SELECT * FROM eventi").fetchall()
           utenti = conn.execute("SELECT * FROM utenti").fetchall()
       return templates.TemplateResponse("eventiP.html", {"request": request, "events": events, "utenti": utenti})
   except Exception as e:
       return {"error": str(e)}
  
@app.get("/eventiO", response_class=HTMLResponse)
async def get_eventiO(request: Request):
   try:
       with get_db_connection() as conn:
           events = conn.execute("SELECT * FROM eventi").fetchall()
           utenti = conn.execute("SELECT * FROM utenti").fetchall()
       return templates.TemplateResponse("eventiO.html", {"request": request, "events": events, "utenti": utenti})
   except Exception as e:
       return {"error": str(e)}

@app.post("/crea_organizzatore")
async def crea_organizzatore(
   nome: str = Form(...),
   cognome: str = Form(...),
   email: str = Form(...),
   telefono: str = Form(...),
   data_nascita: str = Form(...)
):
   try:
       with get_db_connection() as conn:
           cursor = conn.execute('SELECT * FROM utenti WHERE email = ?', (email,))
           existing_email = cursor.fetchone()
           if existing_email:
               raise HTTPException(status_code=409, detail="Email già in uso")
           conn.execute('''
               INSERT INTO utenti (nome, cognome, email, telefono, data_nascita)
               VALUES (?, ?, ?, ?, ?)
           ''', (nome, cognome, email, telefono, data_nascita))
           conn.commit()
           cursor = conn.execute("SELECT last_insert_rowid()")
           id_organizzatore = cursor.fetchone()[0]
       return {
           "message": "Organizzatore creato con successo!",
           "nome": nome,
           "cognome": cognome,
           "email": email,
           "telefono": telefono,
           "data_nascita": data_nascita,
           "organizzatoreId": id_organizzatore
       }
   except HTTPException as e:
       raise e
   except sqlite3.Error as e:
       return {"error": f"Errore durante la creazione dell'organizzatore: {e}"}

@app.post("/partecipa_evento/{event_id}")
async def partecipa_evento(event_id: int, partecipazione: Partecipazione):
    # Verifica se l'utente è già registrato per l'evento
    if is_user_registered(event_id, partecipazione.userId):
        raise HTTPException(status_code=422, detail="User already registered for this event")
    
    # Registra l'utente per l'evento
    register_user(event_id, partecipazione.userId)
    
    # Riduci il numero di posti disponibili
    reduce_available_slots(event_id)
    
    return {"message": "Registration successful"}

def is_user_registered(event_id: int, user_id: int) -> bool:
    # Implementa la logica per verificare se l'utente è già registrato
    # Esempio di controllo: ritorna True se l'utente è già registrato
    return False

def register_user(event_id: int, user_id: int):
    # Implementa la logica per registrare l'utente all'evento
    pass

def reduce_available_slots(event_id: int):
    # Implementa la logica per ridurre il numero di posti disponibili
    pass

@app.get("/admin", response_class=HTMLResponse)
async def read_admin(request: Request):
   return templates.TemplateResponse("admin.html", {"request": request})

@app.post("/login")
async def login(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    user_type: str = Form(...)
):
    try:
        print(f"User type ricevuto dal form: {user_type}")
        if user_type not in ["organizzatore", "partecipante"]:
            raise HTTPException(status_code=400, detail="Valore di 'user_type' non valido")

        conn = get_db_connection()
        cursor = conn.cursor()
        user = cursor.execute("SELECT * FROM utenti WHERE email = ?", (email,)).fetchone()
        if not user:
            raise HTTPException(status_code=401, detail="Utente non trovato")

        print(f"Utente trovato: ID {user['id']}, email: {user['email']}")
        stored_password = user["password"]
        print(f"Stored password: {stored_password}")

        if not bcrypt.checkpw(password.encode('utf-8'), stored_password.encode('utf-8')):
            print("Password non valida!")
            raise HTTPException(status_code=401, detail="Password non valida")

        print(f"Utente {email} autenticato correttamente!")

        # Genera il token JWT, includendo eventualmente il ruolo
        token_payload = {"user_id": user["id"], "ruolo": user_type}
        token = jwt.encode(token_payload, SECRET_KEY, algorithm=ALGORITHM)

        # Scegli il redirect in base al tipo d'utente e, se usi template, puntare a endpoint dinamici
        if user_type == "organizzatore":
            redirect_url = "/crea_evento"
        elif user_type == "partecipante":
            redirect_url = "/eventiP"
        else:
            raise HTTPException(status_code=400, detail="Valore di 'user_type' non valido")

        response = RedirectResponse(url=redirect_url, status_code=303)
        # Imposta il token in un cookie httpOnly per la sicurezza
        response.set_cookie(key="access_token", value=f"Bearer {token}", httponly=True)
        print(f"Utente {email} reindirizzato a {response.headers.get('location')}")
        return response

    except sqlite3.Error as e:
        print(f"Errore nel database: {e}")
        raise HTTPException(status_code=500, detail="Errore interno del server")
    except Exception as e:
        print(f"Errore generico: {e}")
        raise HTTPException(status_code=500, detail="Errore interno del server")

@app.get("/login", response_class=HTMLResponse)
async def get_login(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/registrazione", response_class=HTMLResponse)
async def get_registrazione(request: Request):
   return templates.TemplateResponse("/registrazione.html", {"request": request})

@app.post("/registrazione")
async def registrazione(
   nome: str = Form(...),
   cognome: str = Form(...),
   email: str = Form(...),
   telefono: str = Form(...),
   data_nascita: str = Form(...),
   password: str = Form(...)
):
   hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
   try:
       with get_db_connection() as conn:
           cursor = conn.execute("SELECT * FROM utenti WHERE email = ?", (email,))
           if cursor.fetchone():
               raise HTTPException(status_code=409, detail="Email già in uso")
           conn.execute('''
               INSERT INTO utenti (nome, cognome, email, telefono, data_nascita, password)
               VALUES (?, ?, ?, ?, ?, ?)
           ''', (nome, cognome, email, telefono, data_nascita, hashed_password))
           conn.commit()
       return RedirectResponse(url="/", status_code=303)
   except sqlite3.Error as e:
       return {"error": f"Errore durante la registrazione: {e}"}

@app.get("/paginaProtetta", response_class=HTMLResponse)
async def read_protected_page(request: Request):
   try:
       with get_db_connection() as conn:
           eventi = conn.execute("SELECT * FROM eventi").fetchall()
           utenti = conn.execute("SELECT * FROM utenti").fetchall()
       return templates.TemplateResponse("paginaProtetta.html", {"request": request, "eventi": eventi, "utenti": utenti})
   except sqlite3.Error as e:
       return {"error": f"Errore nel caricamento degli eventi e degli utenti: {e}"}

@app.post("/elimina_evento/{event_id}")
async def elimina_evento(event_id: int):
   try:
       with get_db_connection() as conn:
           conn.execute("DELETE FROM eventi WHERE id = ?", (event_id,))
           conn.commit()
       return {"message": "Evento eliminato con successo!"}
   except sqlite3.Error as e:
       return {"error": f"Errore durante l'eliminazione dell'evento: {e}"}

@app.post("/elimina_utente/{user_id}")
async def elimina_utente(user_id: int):
   try:
       with get_db_connection() as conn:
           conn.execute("DELETE FROM utenti WHERE id = ?", (user_id,))
           conn.commit()
       return {"message": "Utente eliminato con successo!"}
   except sqlite3.Error as e:
       return {"error": f"Errore durante l'eliminazione dell'utente: {e}"}
  
@app.get("/elenco_partecipanti", response_class=HTMLResponse)
async def elenco_partecipanti(
    request: Request,
    event_id: int = Query(..., alias="evento_id")
):
    try:
        with get_db_connection() as conn:
            # Query per recuperare i partecipanti con tutti i dati
            partecipanti = conn.execute('''
                SELECT u.nome, u.cognome, u.email
                FROM partecipazioni p
                JOIN utenti u ON p.utente_id = u.id
                WHERE p.evento_id = ?
            ''', (event_id,)).fetchall()
        
        # Trasforma i risultati in una lista di dizionari
        partecipanti = [dict(partecipante) for partecipante in partecipanti]
        
        # Passa i dati dei partecipanti al template
        return templates.TemplateResponse(
            "elenco_utenti.html", 
            {"request": request, "partecipanti": partecipanti}
        )
    except sqlite3.Error as e:
        return templates.TemplateResponse(
            "elenco_utenti.html", 
            {"request": request, "partecipanti": [], "error": str(e)}
        )

@app.get("/api/partecipanti", response_class=JSONResponse)
async def api_partecipanti(evento_id: Optional[int] = Query(None)):
    try:
        with get_db_connection() as conn:
            if evento_id is not None:
                query = '''
                    SELECT u.nome, u.cognome, u.email 
                    FROM partecipazioni p
                    JOIN utenti u ON p.utente_id = u.id
                    WHERE p.evento_id = ?
                '''
                partecipanti = conn.execute(query, (evento_id,)).fetchall()
            else:
                query = '''
                    SELECT u.nome, u.cognome, u.email, p.evento_id
                    FROM partecipazioni p
                    JOIN utenti u ON p.utente_id = u.id
                '''
                partecipanti = conn.execute(query).fetchall()
        partecipanti = [dict(partecipante) for partecipante in partecipanti]
        return {"partecipanti": partecipanti}
    except sqlite3.Error as e:
        return {"error": f"Errore nel recupero dei dati: {e}"}

@app.get("/api/tutti_partecipanti", response_class=JSONResponse)
async def api_tutti_partecipanti():
    try:
        with get_db_connection() as conn:
            partecipanti = conn.execute('''
                SELECT u.nome, u.cognome, u.email, p.evento_id
                FROM partecipazioni p
                JOIN utenti u ON p.utente_id = u.id
            ''').fetchall()
        partecipanti = [dict(partecipante) for partecipante in partecipanti]
        return {"partecipanti": partecipanti}
    except sqlite3.Error as e:
        return {"error": f"Errore nel recupero dei dati: {e}"}
