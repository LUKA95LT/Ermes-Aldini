import sqlite3

def elimina_eventi(solo_id=None):
    conn = sqlite3.connect('eventi.db')
    cursor = conn.cursor()
    
    if solo_id is None:
        # Elimina tutti gli eventi
        query = "DELETE FROM eventi;"
        cursor.execute(query)
    else:
        # Elimina l'evento con un id specifico
        query = "DELETE FROM eventi WHERE id = ?;"
        cursor.execute(query, (solo_id,))
    
    conn.commit()
    conn.close()
    print("Eliminazione completata.")

# Per eliminare tutti gli eventi:
elimina_eventi()

# Per eliminare l'evento con id = 3:
# elimina_eventi(solo_id=3)
