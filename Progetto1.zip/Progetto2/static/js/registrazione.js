document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector("form");

  form.addEventListener("submit", function (event) {
    event.preventDefault();

    const organizzatore = new FormData();
    const nome = document.getElementById("nome").value.trim();
    const cognome = document.getElementById("cognome").value.trim();
    const email = document.getElementById("email").value.trim();
    const telefono = document.getElementById("numero").value.trim();
    const dataNascitaValue = document.getElementById("nascita").value;

    organizzatore.append("nome", nome);
    organizzatore.append("cognome", cognome);
    organizzatore.append("email", email);
  });
});