DROP TABLE IF EXISTS partecipazioni;
DROP TABLE IF EXISTS eventi;
DROP TABLE IF EXISTS utenti;

CREATE TABLE utenti (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    cognome TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    telefono TEXT NOT NULL,
    data_nascita TEXT NOT NULL,
    password TEXT NOT NULL
);

CREATE TABLE eventi (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    data_inizio TEXT NOT NULL,
    data_fine TEXT NOT NULL,
    posti INTEGER NOT NULL,
    descrizione TEXT,
    organizzatore_id INTEGER,
    FOREIGN KEY (organizzatore_id) REFERENCES utenti(id)
);

CREATE TABLE partecipazioni (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    utente_id INTEGER NOT NULL,
    evento_id INTEGER NOT NULL,
    FOREIGN KEY (utente_id) REFERENCES utenti(id),
    FOREIGN KEY (evento_id) REFERENCES eventi(id),
    UNIQUE(utente_id, evento_id)
);

-- Trigger per aggiornare la tabella partecipazioni quando viene inserito un nuovo utente
CREATE TRIGGER after_insert_utenti
AFTER INSERT ON utenti
FOR EACH ROW
BEGIN
    INSERT INTO partecipazioni (utente_id, evento_id)
    SELECT NEW.id, e.id FROM eventi e
    WHERE e.nome IN ('Concerto Rock', 'Workshop Fotografia', 'Degustazione Vini');
END;

-- Trigger per aggiornare la tabella partecipazioni quando viene inserito un nuovo evento
CREATE TRIGGER after_insert_eventi
AFTER INSERT ON eventi
FOR EACH ROW
BEGIN
    INSERT INTO partecipazioni (utente_id, evento_id)
    SELECT u.id, NEW.id FROM utenti u
    WHERE u.email IN ('marco.cavallo@email.it', 'ernesto.soveretto@email.it');
END;

INSERT INTO utenti (nome, cognome, email, telefono, data_nascita, password)
VALUES 
    ('Diego', 'Ippopolito', 'diego.ippopolito@email.it', '3331234567', '1980-05-10', 'hashed_password1'),
    ('Marco', 'Cavallo', 'marco.cavallo@email.it', '3339876543', '1985-08-15', 'hashed_password2'),
    ('Ernesto', 'Soveretto', 'ernesto.soveretto@email.it', '3351122334', '1990-02-20', 'hashed_password3'),
    ('Luca', 'Troc', 'luca.troc@email.it', '3387654321', '1975-11-30', 'hashed_password4');

INSERT INTO eventi (nome, data_inizio, data_fine, posti, descrizione, organizzatore_id)
VALUES 
    ('Concerto Rock', '2025-04-15 20:00:00', '2025-04-15 23:00:00', 200, 'Grande concerto rock con band locali', 1),
    ('Workshop Fotografia', '2025-04-20 10:00:00', '2025-04-20 16:00:00', 30, 'Workshop per imparare le basi della fotografia', 4),
    ('Degustazione Vini', '2025-05-10 18:30:00', '2025-05-10 21:30:00', 50, 'Degustazione di vini locali con sommelier', 1);

INSERT INTO partecipazioni (utente_id, evento_id)
VALUES 
    ((SELECT id FROM utenti WHERE email = 'marco.cavallo@email.it'), (SELECT id FROM eventi WHERE nome = 'Concerto Rock')),  
    ((SELECT id FROM utenti WHERE email = 'ernesto.soveretto@email.it'), (SELECT id FROM eventi WHERE nome = 'Concerto Rock')), 
    ((SELECT id FROM utenti WHERE email = 'marco.cavallo@email.it'), (SELECT id FROM eventi WHERE nome = 'Workshop Fotografia')),  
    ((SELECT id FROM utenti WHERE email = 'ernesto.soveretto@email.it'), (SELECT id FROM eventi WHERE nome = 'Degustazione Vini'));  

SELECT e.nome AS evento, e.data_inizio, u.nome || ' ' || u.cognome AS organizzatore
FROM eventi e
JOIN utenti u ON e.organizzatore_id = u.id;

SELECT u.nome || ' ' || u.cognome AS partecipante, e.nome AS evento
FROM partecipazioni p
JOIN utenti u ON p.utente_id = u.id
JOIN eventi e ON p.evento_id = e.id;

SELECT e.nome AS evento, COUNT(p.id) AS numero_partecipanti
FROM eventi e
LEFT JOIN partecipazioni p ON e.id = p.evento_id
GROUP BY e.id;
